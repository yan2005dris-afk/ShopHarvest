(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
const DEFAULT_APP_URL = "http://localhost:4200";
async function resolveAppUrl() {
  const { appUrl } = await chrome.storage.local.get("appUrl");
  return typeof appUrl === "string" && appUrl.length > 0 ? appUrl : DEFAULT_APP_URL;
}
const btnOpen = document.getElementById("btn-open-app");
const errorEl = document.getElementById("error");
btnOpen.addEventListener("click", async () => {
  try {
    const url = await resolveAppUrl();
    await chrome.tabs.create({ url, active: true });
    window.close();
  } catch (err) {
    errorEl.textContent = `Could not open the web app: ${String(err)}`;
    errorEl.classList.remove("hidden");
  }
});
