(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
let currentDomain = "";
let currentTabId = 0;
let currentTabUrl;
let currentRule = null;
let pendingMappings = /* @__PURE__ */ new Map();
let extractedProducts = [];
const views = {
  home: document.getElementById("view-home"),
  mapping: document.getElementById("view-mapping"),
  data: document.getElementById("view-data")
};
const el = {
  domainBadge: document.getElementById("domain-badge"),
  ruleStatus: document.getElementById("rule-status"),
  btnStartMapping: document.getElementById("btn-start-mapping"),
  btnExtract: document.getElementById("btn-extract"),
  btnViewData: document.getElementById("btn-view-data"),
  homeError: document.getElementById("home-error"),
  btnSaveRule: document.getElementById("btn-save-rule"),
  btnCancelMapping: document.getElementById("btn-cancel-mapping"),
  btnExportCsv: document.getElementById("btn-export-csv"),
  btnClearData: document.getElementById("btn-clear-data"),
  btnBack: document.getElementById("btn-back"),
  productCount: document.getElementById("product-count"),
  tableHead: document.getElementById("table-head"),
  tableBody: document.getElementById("table-body"),
  toast: document.getElementById("toast")
};
async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url) {
    showError("Cannot access this page.");
    return;
  }
  currentTabId = tab.id;
  currentTabUrl = tab.url;
  const url = new URL(tab.url);
  currentDomain = url.hostname;
  el.domainBadge.textContent = currentDomain;
  currentRule = await bgMessage("GET_RULE", currentDomain);
  if (currentRule) {
    el.ruleStatus.classList.remove("hidden");
  }
  showView("home");
  bindEvents();
}
function showView(name) {
  Object.values(views).forEach((v) => v.classList.add("hidden"));
  views[name].classList.remove("hidden");
}
function bindEvents() {
  el.btnStartMapping.addEventListener("click", onStartMapping);
  el.btnExtract.addEventListener("click", onExtract);
  el.btnViewData.addEventListener("click", onViewData);
  el.btnSaveRule.addEventListener("click", onSaveRule);
  el.btnCancelMapping.addEventListener("click", onCancelMapping);
  el.btnExportCsv.addEventListener("click", onExportCsv);
  el.btnClearData.addEventListener("click", onClearData);
  el.btnBack.addEventListener("click", () => showView("home"));
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "FIELD_ASSIGNED") {
      const { field, selector, type, attribute } = message.payload;
      onFieldAssigned(field, selector, type, attribute);
    }
  });
}
async function onStartMapping() {
  pendingMappings = /* @__PURE__ */ new Map();
  resetMappingView();
  try {
    await contentMessage("START_MAPPING", void 0);
    showView("mapping");
  } catch {
    showError("Cannot inject into this page. Try a regular website.");
  }
}
async function onExtract() {
  if (!currentRule) {
    showError("No rule saved for this domain. Map fields first.");
    return;
  }
  el.homeError.classList.add("hidden");
  try {
    const result = await contentMessage("EXTRACT", currentRule);
    extractedProducts = result.products ?? [];
    await fetch("http://localhost:3000/products/ingest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain: currentDomain, pageUrl: currentTabUrl, products: extractedProducts })
    }).catch(() => {
    });
    renderDataView(extractedProducts);
    showView("data");
  } catch (err) {
    showError(`Extraction failed: ${err.message}`);
  }
}
async function onViewData() {
  const products = await bgMessage("GET_PRODUCTS", currentDomain);
  extractedProducts = products ?? [];
  renderDataView(extractedProducts);
  showView("data");
}
function onFieldAssigned(field, selector, type, attribute) {
  pendingMappings.set(field, { selector, type, attribute });
  if (field === "container") {
    updateFieldRow("container", selector);
  } else {
    updateFieldRow(field, selector);
  }
  checkSaveEnabled();
}
async function onSaveRule() {
  const containerEntry = pendingMappings.get("container");
  if (!containerEntry) return;
  const fieldMappings = [];
  pendingMappings.forEach((value, key) => {
    if (key === "container") return;
    fieldMappings.push({
      canonicalField: key,
      selector: value.selector,
      type: value.type,
      attribute: value.attribute
    });
  });
  const rule = {
    domain: currentDomain,
    containerSelector: containerEntry.selector,
    fieldMappings,
    createdAt: currentRule?.createdAt ?? Date.now(),
    updatedAt: Date.now()
  };
  await bgMessage("SAVE_RULE", rule);
  currentRule = rule;
  await contentMessage("STOP_MAPPING", void 0).catch(() => {
  });
  el.ruleStatus.classList.remove("hidden");
  showToast("Rule saved!");
  showView("home");
}
async function onCancelMapping() {
  await contentMessage("STOP_MAPPING", void 0).catch(() => {
  });
  showView("home");
}
function onExportCsv() {
  if (!extractedProducts.length) return;
  const headers = Object.keys(extractedProducts[0]);
  const rows = extractedProducts.map((p) => headers.map((h) => JSON.stringify(p[h] ?? "")).join(","));
  const csv = [headers.join(","), ...rows].join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${currentDomain}-products.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
async function onClearData() {
  await bgMessage("CLEAR_PRODUCTS", currentDomain);
  extractedProducts = [];
  renderDataView([]);
  showToast("Data cleared");
}
function resetMappingView() {
  const fieldIds = ["container", "title", "price", "imageUrl", "sku", "currency", "description"];
  fieldIds.forEach((f) => {
    const span = document.getElementById(`field-${f}`);
    if (span) {
      span.textContent = "not set";
      span.classList.remove("set");
    }
  });
  el.btnSaveRule.disabled = true;
}
function updateFieldRow(field, selector) {
  const span = document.getElementById(`field-${field}`);
  if (!span) return;
  span.textContent = selector.length > 30 ? `…${selector.slice(-27)}` : selector;
  span.classList.add("set");
}
function checkSaveEnabled() {
  const hasTitle = pendingMappings.has("title");
  const hasPrice = pendingMappings.has("price");
  const hasContainer = pendingMappings.has("container");
  el.btnSaveRule.disabled = !(hasTitle && hasPrice && hasContainer);
}
function renderDataView(products) {
  el.productCount.textContent = `${products.length} product(s) extracted`;
  el.tableHead.innerHTML = "";
  el.tableBody.innerHTML = "";
  if (!products.length) return;
  const headers = Object.keys(products[0]);
  headers.forEach((h) => {
    const th = document.createElement("th");
    th.textContent = h;
    el.tableHead.appendChild(th);
  });
  const preview = products.slice(0, 5);
  preview.forEach((product) => {
    const tr = document.createElement("tr");
    headers.forEach((h) => {
      const td = document.createElement("td");
      td.textContent = String(product[h] ?? "");
      td.title = String(product[h] ?? "");
      tr.appendChild(td);
    });
    el.tableBody.appendChild(tr);
  });
}
function bgMessage(type, payload) {
  return chrome.runtime.sendMessage({ type, payload });
}
function contentMessage(type, payload) {
  return chrome.tabs.sendMessage(currentTabId, { type, payload });
}
function showError(msg) {
  el.homeError.textContent = msg;
  el.homeError.classList.remove("hidden");
}
let toastTimer = null;
function showToast(msg, isError = false) {
  el.toast.textContent = msg;
  el.toast.className = `toast${isError ? " error-toast" : ""}`;
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.toast.classList.add("hidden");
  }, 2500);
}
init().catch(console.error);
