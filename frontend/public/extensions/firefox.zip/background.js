let activeSession = null;
chrome.runtime.onConnectExternal.addListener((port) => {
  if (port.name !== "mapping-session") return;
  port.onMessage.addListener(async (msg) => {
    if (msg.type !== "OPEN_MAPPER") return;
    const { url } = msg.payload;
    if (activeSession) {
      chrome.tabs.remove(activeSession.scrapingTabId).catch(() => {
      });
      activeSession = null;
    }
    try {
      const tab = await chrome.tabs.create({ url, active: true });
      if (!tab.id) throw new Error("Tab creation failed");
      activeSession = { scrapingTabId: tab.id, port, mappings: {} };
      waitForTabLoad(tab.id, () => {
        chrome.tabs.sendMessage(tab.id, {
          type: "START_MAPPING",
          payload: { fromFrontend: true }
        });
      });
    } catch (err) {
      port.postMessage({ type: "MAPPING_ERROR", payload: { message: String(err) } });
    }
  });
  port.onDisconnect.addListener(() => {
    if (activeSession && activeSession.port === port) {
      chrome.tabs.remove(activeSession.scrapingTabId).catch(() => {
      });
      activeSession = null;
    }
  });
});
function waitForTabLoad(tabId, callback) {
  const listener = (updatedTabId, info) => {
    if (updatedTabId === tabId && info.status === "complete") {
      chrome.tabs.onUpdated.removeListener(listener);
      setTimeout(callback, 500);
    }
  };
  chrome.tabs.onUpdated.addListener(listener);
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const senderTabId = sender.tab?.id;
  if (activeSession && senderTabId === activeSession.scrapingTabId) {
    if (message.type === "FIELD_ASSIGNED") {
      const mapping = message.payload;
      activeSession.mappings[mapping.canonicalField] = mapping;
      activeSession.port.postMessage({ type: "FIELD_ASSIGNED", payload: message.payload });
      sendResponse({ ok: true });
      return true;
    }
    if (message.type === "MAPPING_COMPLETE") {
      activeSession.port.postMessage({ type: "MAPPING_COMPLETE", payload: message.payload });
      chrome.tabs.remove(activeSession.scrapingTabId).catch(() => {
      });
      activeSession = null;
      sendResponse({ ok: true });
      return true;
    }
    if (message.type === "MAPPING_CANCELLED") {
      activeSession.port.postMessage({ type: "MAPPING_CANCELLED" });
      chrome.tabs.remove(activeSession.scrapingTabId).catch(() => {
      });
      activeSession = null;
      sendResponse({ ok: true });
      return true;
    }
  }
  handleStorageMessage(message).then(sendResponse).catch((err) => {
    sendResponse({ error: err.message });
  });
  return true;
});
async function handleStorageMessage(message) {
  const { type, payload } = message;
  switch (type) {
    case "GET_RULE": {
      const domain = payload;
      const data = await getStorage();
      return data.rules[domain] ?? null;
    }
    case "SAVE_RULE": {
      const rule = payload;
      const data = await getStorage();
      data.rules[rule.domain] = rule;
      await setStorage(data);
      return { success: true };
    }
    case "GET_RULES": {
      const data = await getStorage();
      return data.rules;
    }
    case "SAVE_PRODUCTS": {
      const { domain, products } = payload;
      const data = await getStorage();
      const existing = data.products[domain] ?? [];
      data.products[domain] = [...existing, ...products];
      await setStorage(data);
      return { success: true };
    }
    case "GET_PRODUCTS": {
      const domain = payload;
      const data = await getStorage();
      return data.products[domain] ?? [];
    }
    case "DELETE_RULE": {
      const domain = payload;
      const data = await getStorage();
      delete data.rules[domain];
      delete data.products[domain];
      await setStorage(data);
      return { success: true };
    }
    case "CLEAR_PRODUCTS": {
      const domain = payload;
      const data = await getStorage();
      data.products[domain] = [];
      await setStorage(data);
      return { success: true };
    }
    default:
      return null;
  }
}
async function getStorage() {
  const result = await chrome.storage.local.get(["rules", "products"]);
  return {
    rules: result["rules"] ?? {},
    products: result["products"] ?? {}
  };
}
async function setStorage(data) {
  await chrome.storage.local.set({ rules: data.rules, products: data.products });
}
