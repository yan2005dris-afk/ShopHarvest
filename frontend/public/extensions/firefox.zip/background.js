const ALARM_PREFIX = "replay:";
const DEFAULT_BACKEND_URL = "http://localhost:3000";
async function getSchedules() {
  const { schedules } = await chrome.storage.local.get("schedules");
  return schedules ?? {};
}
async function setSchedules(schedules) {
  await chrome.storage.local.set({ schedules });
}
async function getBackendUrl() {
  const { backendUrl } = await chrome.storage.local.get("backendUrl");
  return typeof backendUrl === "string" && backendUrl.length > 0 ? backendUrl : DEFAULT_BACKEND_URL;
}
async function getAuthToken() {
  const { authToken } = await chrome.storage.local.get("authToken");
  return typeof authToken === "string" && authToken.length > 0 ? authToken : null;
}
function authHeaders(token) {
  return token ? { Authorization: `Bearer ${token}` } : {};
}
function alarmName(domain) {
  return ALARM_PREFIX + domain;
}
async function applyAlarm(domain, entry) {
  await chrome.alarms.clear(alarmName(domain));
  if (entry.enabled && entry.intervalMinutes > 0) {
    chrome.alarms.create(alarmName(domain), {
      periodInMinutes: entry.intervalMinutes
    });
  }
}
async function upsertSchedule(domain, intervalMinutes, enabled) {
  const schedules = await getSchedules();
  const entry = {
    intervalMinutes,
    enabled,
    lastRunAt: schedules[domain]?.lastRunAt ?? null
  };
  schedules[domain] = entry;
  await setSchedules(schedules);
  await applyAlarm(domain, entry);
  return entry;
}
async function rearmAll() {
  const schedules = await getSchedules();
  for (const [domain, entry] of Object.entries(schedules)) {
    await applyAlarm(domain, entry);
  }
}
function hostOf(url) {
  if (!url) return null;
  try {
    return new URL(url).hostname;
  } catch {
    return null;
  }
}
async function findTabForDomain(domain) {
  const tabs = await chrome.tabs.query({});
  return tabs.find((tab) => {
    const host = hostOf(tab.url);
    return host === domain || host !== null && host.endsWith("." + domain);
  }) ?? null;
}
async function fetchRule(domain) {
  const base = await getBackendUrl();
  const token = await getAuthToken();
  const res = await fetch(`${base}/domains?host=${encodeURIComponent(domain)}`, {
    headers: authHeaders(token)
  });
  if (!res.ok) return null;
  const rules = await res.json();
  const rule = rules[0];
  if (!rule) return null;
  return {
    domain: rule.domain,
    containerSelector: rule.containerSelector ?? "",
    fieldMappings: rule.fieldMappings ?? [],
    createdAt: 0,
    updatedAt: 0
  };
}
async function runReplay(domain) {
  const schedules = await getSchedules();
  const entry = schedules[domain];
  if (!entry || !entry.enabled) return;
  const tab = await findTabForDomain(domain);
  if (!tab || tab.id === void 0) {
    console.info(`[scheduler] no open tab for ${domain}; skipping replay`);
    return;
  }
  const rule = await fetchRule(domain);
  if (!rule || rule.fieldMappings.length === 0) {
    console.warn(`[scheduler] no saved rule for ${domain}; skipping replay`);
    return;
  }
  let products = [];
  try {
    const response = await chrome.tabs.sendMessage(tab.id, {
      type: "EXTRACT",
      payload: rule
    });
    products = response?.products ?? [];
  } catch (err) {
    console.warn(`[scheduler] EXTRACT failed for ${domain}:`, err);
    return;
  }
  if (products.length === 0) {
    console.info(`[scheduler] replay for ${domain} extracted 0 products`);
    return;
  }
  const base = await getBackendUrl();
  const token = await getAuthToken();
  const ok = await postIngest(base, token, {
    domain,
    pageUrl: tab.url,
    fieldMappings: rule.fieldMappings,
    products
  });
  if (!ok) {
    return;
  }
  entry.lastRunAt = Date.now();
  schedules[domain] = entry;
  await setSchedules(schedules);
  console.info(`[scheduler] replayed ${products.length} products for ${domain}`);
}
async function postIngest(baseUrl, token, body) {
  try {
    const res = await fetch(`${baseUrl}/products/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders(token) },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      console.warn(
        `[scheduler] ingest returned ${res.status} for ${body.domain}; not marking replay as success`
      );
      return false;
    }
    return true;
  } catch (err) {
    console.warn(`[scheduler] ingest fetch failed for ${body.domain}:`, err);
    return false;
  }
}
function initScheduler() {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (!alarm.name.startsWith(ALARM_PREFIX)) return;
    void runReplay(alarm.name.slice(ALARM_PREFIX.length));
  });
  chrome.runtime.onStartup.addListener(() => void rearmAll());
  chrome.runtime.onInstalled.addListener(() => void rearmAll());
  chrome.runtime.onMessageExternal.addListener((message, _sender, sendResponse) => {
    const { type, payload } = message ?? {};
    if (type === "SET_SCHEDULE") {
      const { domain, intervalMinutes, enabled } = payload ?? {};
      if (!domain || typeof intervalMinutes !== "number") {
        sendResponse({ ok: false, error: "domain and intervalMinutes are required" });
        return true;
      }
      void upsertSchedule(domain, intervalMinutes, enabled ?? true).then(
        (entry) => sendResponse({ ok: true, entry })
      );
      return true;
    }
    if (type === "GET_SCHEDULES") {
      void getSchedules().then((schedules) => sendResponse({ ok: true, schedules }));
      return true;
    }
    if (type === "SET_AUTH_TOKEN") {
      const { token } = payload ?? {};
      void chrome.storage.local.set({ authToken: token ?? "" }).then(() => sendResponse({ ok: true }));
      return true;
    }
    return false;
  });
}
initScheduler();
let activeSession = null;
chrome.runtime.onConnectExternal.addListener((port) => {
  if (port.name !== "mapping-session") return;
  port.onMessage.addListener(async (msg) => {
    if (msg.type !== "OPEN_MAPPER") return;
    const { url } = msg.payload;
    if (activeSession) {
      chrome.tabs.remove(activeSession.scrapingTabId).catch(() => {
      });
      activeSession = null;
    }
    try {
      const tab = await chrome.tabs.create({ url, active: true });
      if (!tab.id) throw new Error("Tab creation failed");
      activeSession = { scrapingTabId: tab.id, port, mappings: {} };
      waitForTabLoad(tab.id, () => {
        chrome.tabs.sendMessage(tab.id, {
          type: "START_MAPPING",
          payload: { fromFrontend: true }
        });
      });
    } catch (err) {
      port.postMessage({ type: "MAPPING_ERROR", payload: { message: String(err) } });
    }
  });
  port.onDisconnect.addListener(() => {
    if (activeSession && activeSession.port === port) {
      chrome.tabs.remove(activeSession.scrapingTabId).catch(() => {
      });
      activeSession = null;
    }
  });
});
function waitForTabLoad(tabId, callback) {
  const listener = (updatedTabId, info) => {
    if (updatedTabId === tabId && info.status === "complete") {
      chrome.tabs.onUpdated.removeListener(listener);
      setTimeout(callback, 500);
    }
  };
  chrome.tabs.onUpdated.addListener(listener);
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const senderTabId = sender.tab?.id;
  if (activeSession && senderTabId === activeSession.scrapingTabId) {
    if (message.type === "FIELD_ASSIGNED") {
      const mapping = message.payload;
      activeSession.mappings[mapping.canonicalField] = mapping;
      activeSession.port.postMessage({ type: "FIELD_ASSIGNED", payload: message.payload });
      sendResponse({ ok: true });
      return true;
    }
    if (message.type === "MAPPING_COMPLETE") {
      activeSession.port.postMessage({ type: "MAPPING_COMPLETE", payload: message.payload });
      chrome.tabs.remove(activeSession.scrapingTabId).catch(() => {
      });
      activeSession = null;
      sendResponse({ ok: true });
      return true;
    }
    if (message.type === "MAPPING_CANCELLED") {
      activeSession.port.postMessage({ type: "MAPPING_CANCELLED" });
      chrome.tabs.remove(activeSession.scrapingTabId).catch(() => {
      });
      activeSession = null;
      sendResponse({ ok: true });
      return true;
    }
  }
});
