function announceReady() {
  window.postMessage({ type: "__VS_READY__", extensionId: chrome.runtime.id }, "*");
}
announceReady();
window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  if (e.data?.type === "__VS_PING__") {
    announceReady();
  }
});
let mappingActive = false;
let fromFrontend = false;
let highlightEl = null;
let menuEl = null;
let panelEl = null;
let containerSelector = null;
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const { type, payload } = message;
  switch (type) {
    case "START_MAPPING": {
      const opts = payload ?? {};
      fromFrontend = opts.fromFrontend ?? false;
      startMapping();
      sendResponse({ success: true });
      break;
    }
    case "STOP_MAPPING":
      stopMapping();
      sendResponse({ success: true });
      break;
    case "EXTRACT": {
      const rule = payload;
      const products = extractProducts(rule);
      sendResponse({ products });
      break;
    }
    case "GET_PAGE_INFO":
      sendResponse({ title: document.title, domain: location.hostname });
      break;
    default:
      sendResponse(null);
  }
  return true;
});
function startMapping() {
  mappingActive = true;
  ensureHighlight();
  if (fromFrontend) showPanel();
  document.addEventListener("mouseover", onMouseOver, true);
  document.addEventListener("click", onClick, true);
}
function stopMapping() {
  mappingActive = false;
  document.removeEventListener("mouseover", onMouseOver, true);
  document.removeEventListener("click", onClick, true);
  removeHighlight();
  removeMenu();
  removePanel();
}
function ensureHighlight() {
  if (highlightEl) return;
  highlightEl = document.createElement("div");
  highlightEl.id = "__vs_highlight__";
  Object.assign(highlightEl.style, {
    position: "fixed",
    pointerEvents: "none",
    zIndex: "999999",
    background: "rgba(14, 90, 255, 0.25)",
    border: "2px solid rgba(14, 90, 255, 0.7)",
    borderRadius: "2px",
    transition: "all 0.05s ease",
    display: "none"
  });
  document.documentElement.appendChild(highlightEl);
}
function removeHighlight() {
  highlightEl?.remove();
  highlightEl = null;
}
function onMouseOver(e) {
  if (!mappingActive || !highlightEl) return;
  const target = e.target;
  if (target === highlightEl || target === menuEl || menuEl?.contains(target)) return;
  if (target === panelEl || panelEl?.contains(target)) return;
  const rect = target.getBoundingClientRect();
  Object.assign(highlightEl.style, {
    display: "block",
    top: `${rect.top}px`,
    left: `${rect.left}px`,
    width: `${rect.width}px`,
    height: `${rect.height}px`
  });
}
function onClick(e) {
  if (!mappingActive) return;
  const target = e.target;
  if (menuEl?.contains(target)) return;
  if (panelEl?.contains(target)) return;
  e.preventDefault();
  e.stopPropagation();
  showMenu(e.clientX, e.clientY, target);
}
function showMenu(x, y, target) {
  removeMenu();
  menuEl = document.createElement("div");
  menuEl.id = "__vs_menu__";
  Object.assign(menuEl.style, {
    position: "fixed",
    zIndex: "1000000",
    background: "#1a1a2e",
    border: "1px solid #0f3460",
    borderRadius: "6px",
    padding: "10px",
    boxShadow: "0 4px 20px rgba(0,0,0,0.6)",
    fontFamily: "system-ui, sans-serif",
    fontSize: "13px",
    color: "#eaeaea",
    minWidth: "200px"
  });
  const label = document.createElement("div");
  label.textContent = "Click the card that wraps one product";
  Object.assign(label.style, {
    marginBottom: "8px",
    color: "#888",
    fontSize: "11px",
    maxWidth: "200px"
  });
  menuEl.appendChild(label);
  const containerBtn = createMenuButton("Set as Container", "#e94560", () => assignContainer(target));
  Object.assign(containerBtn.style, { width: "100%", marginBottom: "6px" });
  menuEl.appendChild(containerBtn);
  const cancelBtn = createMenuButton("Cancel", "#333", removeMenu);
  Object.assign(cancelBtn.style, { width: "100%" });
  menuEl.appendChild(cancelBtn);
  document.documentElement.appendChild(menuEl);
  const menuRect = menuEl.getBoundingClientRect();
  const safeX = Math.min(x, window.innerWidth - menuRect.width - 8);
  const safeY = Math.min(y, window.innerHeight - menuRect.height - 8);
  menuEl.style.left = `${Math.max(8, safeX)}px`;
  menuEl.style.top = `${Math.max(8, safeY)}px`;
}
function createMenuButton(text, bg, handler) {
  const btn = document.createElement("button");
  btn.textContent = text;
  Object.assign(btn.style, {
    background: bg,
    color: "#eaeaea",
    border: "none",
    borderRadius: "4px",
    padding: "5px 10px",
    cursor: "pointer",
    fontSize: "12px"
  });
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    handler();
  });
  btn.addEventListener("mouseover", () => {
    btn.style.opacity = "0.8";
  });
  btn.addEventListener("mouseout", () => {
    btn.style.opacity = "1";
  });
  return btn;
}
function removeMenu() {
  menuEl?.remove();
  menuEl = null;
}
function assignContainer(el) {
  const selector = generateSelector(el);
  containerSelector = selector;
  chrome.runtime.sendMessage({
    type: "FIELD_ASSIGNED",
    payload: {
      canonicalField: "container",
      selector,
      type: "text"
    }
  });
  if (fromFrontend) updatePanel();
  removeMenu();
}
function showPanel() {
  if (panelEl) return;
  panelEl = document.createElement("div");
  panelEl.id = "__vs_panel__";
  Object.assign(panelEl.style, {
    position: "fixed",
    top: "16px",
    right: "16px",
    zIndex: "1000001",
    background: "#1a1a2e",
    border: "1px solid #0f3460",
    borderRadius: "8px",
    padding: "14px",
    boxShadow: "0 4px 24px rgba(0,0,0,0.7)",
    fontFamily: "system-ui, sans-serif",
    fontSize: "13px",
    color: "#eaeaea",
    minWidth: "220px",
    userSelect: "none"
  });
  document.documentElement.appendChild(panelEl);
  renderPanel();
}
function renderPanel() {
  if (!panelEl) return;
  panelEl.innerHTML = "";
  const title = document.createElement("div");
  title.textContent = "Visual Scraper";
  Object.assign(title.style, {
    fontWeight: "600",
    marginBottom: "10px",
    fontSize: "14px",
    color: "#4a9eff"
  });
  panelEl.appendChild(title);
  const containerRow = document.createElement("div");
  Object.assign(containerRow.style, { display: "flex", alignItems: "center", gap: "6px", margin: "8px 0" });
  const cDot = document.createElement("span");
  cDot.textContent = containerSelector ? "✓" : "○";
  cDot.style.color = containerSelector ? "#4caf50" : "#555";
  cDot.style.width = "14px";
  const cName = document.createElement("span");
  cName.textContent = "container";
  cName.style.color = containerSelector ? "#eaeaea" : "#666";
  containerRow.appendChild(cDot);
  containerRow.appendChild(cName);
  panelEl.appendChild(containerRow);
  const separator = document.createElement("hr");
  Object.assign(separator.style, { border: "none", borderTop: "1px solid #0f3460", margin: "10px 0" });
  panelEl.appendChild(separator);
  const canFinish = !!containerSelector;
  const finishBtn = document.createElement("button");
  finishBtn.textContent = "Finish — Extract All";
  Object.assign(finishBtn.style, {
    width: "100%",
    background: canFinish ? "#0f3460" : "#2a2a3e",
    color: canFinish ? "#eaeaea" : "#555",
    border: "none",
    borderRadius: "4px",
    padding: "8px",
    cursor: canFinish ? "pointer" : "default",
    fontSize: "13px",
    marginBottom: "6px"
  });
  if (canFinish) {
    finishBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      finishMapping();
    });
  }
  panelEl.appendChild(finishBtn);
  const hint = document.createElement("p");
  hint.textContent = "💡 All fields will be auto-detected — pick in preview";
  Object.assign(hint.style, {
    margin: "0 0 6px",
    fontSize: "10px",
    color: "#4a9eff",
    textAlign: "center"
  });
  panelEl.appendChild(hint);
  const cancelBtn = document.createElement("button");
  cancelBtn.textContent = "Cancel";
  Object.assign(cancelBtn.style, {
    width: "100%",
    background: "transparent",
    color: "#888",
    border: "1px solid #333",
    borderRadius: "4px",
    padding: "6px",
    cursor: "pointer",
    fontSize: "12px"
  });
  cancelBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    cancelMapping();
  });
  panelEl.appendChild(cancelBtn);
}
function updatePanel() {
  if (!panelEl) return;
  renderPanel();
}
function removePanel() {
  panelEl?.remove();
  panelEl = null;
}
function finishMapping() {
  const products = extractProducts({
    containerSelector: containerSelector ?? "",
    fieldMappings: []
  });
  const payload = {
    fieldMappings: [],
    containerSelector,
    domain: location.hostname,
    pageTitle: document.title,
    products,
    extractAll: true
  };
  chrome.runtime.sendMessage({ type: "MAPPING_COMPLETE", payload });
  stopMapping();
}
function cancelMapping() {
  chrome.runtime.sendMessage({ type: "MAPPING_CANCELLED" });
  stopMapping();
}
function generateSelector(el, root) {
  if (el.id) return `#${CSS.escape(el.id)}`;
  const path = [];
  let current = el;
  let depth = 0;
  const MAX_DEPTH = 4;
  const stopAt = document.body;
  while (current && current !== stopAt && current !== document.documentElement && depth < MAX_DEPTH) {
    const tag = current.tagName.toLowerCase();
    const parentEl = current.parentElement;
    const meaningfulClasses = Array.from(current.classList).filter(
      (c) => typeof c === "string" && c.length > 1 && !c.startsWith("_")
    );
    let segment = tag;
    if (meaningfulClasses.length > 0) {
      const topClasses = meaningfulClasses.slice(0, 2);
      segment += topClasses.map((c) => `.${CSS.escape(c)}`).join("");
    } else if (parentEl) {
      const sameTagSiblings = Array.from(parentEl.children).filter(
        (c) => c instanceof Element && c.tagName === current.tagName
      );
      const index = sameTagSiblings.indexOf(current) + 1;
      if (sameTagSiblings.length > 1) {
        segment += `:nth-of-type(${index})`;
      }
    }
    if (parentEl?.id) {
      path.unshift(segment);
      return `#${CSS.escape(parentEl.id)} > ${path.join(" > ")}`;
    }
    path.unshift(segment);
    current = parentEl;
    depth++;
  }
  return path.join(" > ");
}
function parseLocalizedPrice(raw) {
  if (typeof raw !== "string") return null;
  const match = raw.match(/[-+]?\d[\d.,\s]*/);
  if (!match) return null;
  const trimmed = match[0].replace(/\s/g, "");
  if (trimmed === "") return null;
  const lastDot = trimmed.lastIndexOf(".");
  const lastComma = trimmed.lastIndexOf(",");
  const hasDot = lastDot !== -1;
  const hasComma = lastComma !== -1;
  let normalised;
  if (hasDot && hasComma) {
    if (lastComma > lastDot) {
      normalised = trimmed.replace(/\./g, "").replace(",", ".");
    } else {
      normalised = trimmed.replace(/,/g, "");
    }
  } else if (hasComma) {
    normalised = trimmed.replace(",", ".");
  } else {
    normalised = trimmed;
  }
  const parsed = parseFloat(normalised);
  return Number.isFinite(parsed) ? parsed : null;
}
const IMAGE_FIELD_RE = /^image$|^img$|^foto$|^photo$|^picture$|^thumbnail$|^icon$|^imagen$/i;
const CURRENCY_RE = /[$€£¥₹]|USD|EUR|GBP|COP|MXN|ARS|PEN|CLP|S\/\.?|Bs\.?|R\$/;
const RATING_HINT_RE = /rating|stars?|review|puntuaci[oó]n|calificaci[oó]n|estrella/i;
const NON_PRICE_AMOUNT_HINT_RE = /shipping|envio|env[ií]o|flete|delivery|entrega|installment|cuota|financ|unit[- ]?price|per[- ]?unit|precio[- ]?unit|por[- ]?unidad|tax|impuesto|fee|discount|descuento|ahorro|off\b/i;
function isRatingElement(el) {
  if (RATING_HINT_RE.test(el.className)) return true;
  const ariaLabel = el.getAttribute("aria-label");
  if (ariaLabel && RATING_HINT_RE.test(ariaLabel)) return true;
  if (el.getAttribute("itemprop") === "ratingValue") return true;
  return !!el.closest(
    '[class*="rating" i], [class*="stars" i], [class*="review" i], [itemprop="ratingValue"]'
  );
}
function isNonPriceAmountElement(el) {
  if (NON_PRICE_AMOUNT_HINT_RE.test(el.className)) return true;
  const ariaLabel = el.getAttribute("aria-label");
  if (ariaLabel && NON_PRICE_AMOUNT_HINT_RE.test(ariaLabel)) return true;
  return !!el.closest(
    '[class*="shipping" i], [class*="envio" i], [class*="delivery" i], [class*="installment" i], [class*="cuota" i], [class*="discount" i], [class*="descuento" i]'
  );
}
const LAZY_SRC_ATTRS = ["data-src", "data-lazy-src", "data-original", "data-lazy", "data-echo"];
const LAZY_SRCSET_ATTRS = ["data-srcset", "srcset"];
const PLACEHOLDER_IMAGE_RE = /placeholder|blank\.gif|spacer\.gif|lazy(?:load)?\.(?:svg|gif|png)|1x1|transparent\.(?:gif|png)|loading\.(?:svg|gif)/i;
function firstUrlFromSrcset(value) {
  const first = value.split(",")[0]?.trim().split(/\s+/)[0];
  return first && first.length > 0 ? first : null;
}
function resolveImageSrc(el) {
  for (const attr of LAZY_SRC_ATTRS) {
    const v = el.getAttribute(attr);
    if (v && !PLACEHOLDER_IMAGE_RE.test(v)) return v;
  }
  for (const attr of LAZY_SRCSET_ATTRS) {
    const raw = el.getAttribute(attr);
    const url = raw ? firstUrlFromSrcset(raw) : null;
    if (url && !PLACEHOLDER_IMAGE_RE.test(url)) return url;
  }
  const src = el.getAttribute("src");
  if (src && !src.startsWith("data:image") && !PLACEHOLDER_IMAGE_RE.test(src)) return src;
  return null;
}
function findNearbyImageSrc(el) {
  const ownImg = el.querySelector("img");
  if (ownImg) {
    const src = resolveImageSrc(ownImg);
    if (src) return src;
  }
  let current = el;
  for (let depth = 0; depth < 3 && current; depth++) {
    const parentEl = current.parentElement;
    if (!parentEl) break;
    const siblingImg = Array.from(parentEl.children).find(
      (sibling) => sibling instanceof Element && sibling !== current && sibling.tagName === "IMG"
    );
    const siblingSrc = siblingImg ? resolveImageSrc(siblingImg) : null;
    if (siblingSrc) {
      return siblingSrc;
    }
    const parentImg = parentEl.querySelector("img");
    if (parentImg && parentImg !== ownImg) {
      const parentSrc = resolveImageSrc(parentImg);
      if (parentSrc) return parentSrc;
    }
    current = parentEl;
  }
  return null;
}
function extractFieldsFromElement(root, mappings) {
  const product = {};
  for (const mapping of mappings) {
    const isPriceField = /precio|price|amount|cost|costo/i.test(mapping.canonicalField);
    if (isPriceField) {
      const allEls = root.querySelectorAll(mapping.selector);
      const prices = [];
      for (const el2 of allEls) {
        if (isRatingElement(el2) || isNonPriceAmountElement(el2)) continue;
        const raw = el2.textContent?.trim() ?? "";
        const parsed = parseLocalizedPrice(raw);
        if (parsed !== null && parsed > 0) {
          prices.push(parsed);
        }
      }
      if (prices.length > 0) {
        product[mapping.canonicalField] = Math.min(...prices);
      }
      continue;
    }
    const el = root.querySelector(mapping.selector);
    if (!el) continue;
    if (mapping.type === "text") {
      product[mapping.canonicalField] = el.textContent?.trim() ?? null;
    } else if (mapping.type === "attribute") {
      product[mapping.canonicalField] = el.getAttribute(mapping.attribute ?? "") ?? null;
    } else if (mapping.type === "html") {
      product[mapping.canonicalField] = el.innerHTML?.trim() ?? null;
    }
    if (mapping.type === "text" && IMAGE_FIELD_RE.test(mapping.canonicalField)) {
      const raw = product[mapping.canonicalField];
      if (typeof raw === "string" && raw && !raw.startsWith("http")) {
        const src = findNearbyImageSrc(el);
        if (src) product[mapping.canonicalField] = src;
      }
    }
    coercePriceField(product, mapping);
  }
  const hasValue = Object.values(product).some((v) => v !== null && v !== void 0);
  return hasValue ? product : null;
}
function coercePriceField(product, mapping) {
  if (typeof product[mapping.canonicalField] === "string" && /precio|price|amount|cost|costo/i.test(mapping.canonicalField)) {
    const parsed = parseLocalizedPrice(
      product[mapping.canonicalField]
    );
    if (parsed !== null) {
      product[mapping.canonicalField] = parsed;
    }
  }
}
function extractProductsGlobal(mappings) {
  const fieldResults = {};
  let maxCount = 0;
  for (const m of mappings) {
    const nodes = Array.from(document.querySelectorAll(m.selector));
    fieldResults[m.canonicalField] = nodes;
    if (nodes.length > maxCount) maxCount = nodes.length;
  }
  if (maxCount === 0) return [];
  const counts = mappings.map((m) => fieldResults[m.canonicalField].length).sort((a, b) => a - b);
  const target = counts[Math.floor(counts.length / 2)];
  const products = [];
  for (let i = 0; i < target; i++) {
    const product = {};
    for (const m of mappings) {
      const el = fieldResults[m.canonicalField][i];
      if (!el) continue;
      if (m.type === "text") {
        product[m.canonicalField] = el.textContent?.trim() ?? null;
      } else if (m.type === "attribute") {
        product[m.canonicalField] = el.getAttribute(m.attribute ?? "") ?? null;
      } else if (m.type === "html") {
        product[m.canonicalField] = el.innerHTML?.trim() ?? null;
      }
      if (m.type === "text" && IMAGE_FIELD_RE.test(m.canonicalField)) {
        const raw = product[m.canonicalField];
        if (typeof raw === "string" && raw && !raw.startsWith("http")) {
          const src = findNearbyImageSrc(el);
          if (src) product[m.canonicalField] = src;
        }
      }
      coercePriceField(product, m);
    }
    const hasTitle = mappings.some(
      (m) => /^title$|^nombre$|^name$|^titulo$/i.test(m.canonicalField) && product[m.canonicalField] != null && product[m.canonicalField] !== ""
    );
    if (hasTitle) products.push(product);
  }
  return products;
}
function extractAllFromContainer(container) {
  const result = {};
  const getAllTextEls = (selector) => {
    try {
      return Array.from(container.querySelectorAll(selector)).map((el) => ({ el, text: el.textContent?.trim() ?? "" })).filter((r) => r.text.length > 0);
    } catch {
      return [];
    }
  };
  const getAllText = (selector) => getAllTextEls(selector).map((r) => r.text);
  const getAllImages = (selector) => {
    try {
      return Array.from(container.querySelectorAll(selector)).map(resolveImageSrc).filter((src) => !!src && src.length > 0);
    } catch {
      return [];
    }
  };
  const getAllLinks = (selector) => {
    try {
      return Array.from(container.querySelectorAll(selector)).map((el) => el.href).filter((href) => !!href && href.length > 0);
    } catch {
      return [];
    }
  };
  const collectPrices = (selectors, requireCurrency) => {
    const found = [];
    for (const sel of selectors) {
      for (const { el, text } of getAllTextEls(sel)) {
        if (isRatingElement(el) || isNonPriceAmountElement(el)) continue;
        if (requireCurrency && !CURRENCY_RE.test(text)) continue;
        const parsed = parseLocalizedPrice(text);
        if (parsed !== null && parsed > 0) found.push(parsed);
      }
    }
    return found;
  };
  const specificPriceSelectors = [
    '[class*="price" i]',
    '[class*="precio" i]',
    "[data-price]",
    '[class*="amount" i]'
  ];
  let allPrices = collectPrices(specificPriceSelectors, true);
  if (allPrices.length === 0) {
    allPrices = collectPrices(specificPriceSelectors, false);
  }
  if (allPrices.length === 0) {
    allPrices = collectPrices(["span", "div"], true);
  }
  const uniquePrices = [...new Set(allPrices)].sort((a, b) => a - b);
  if (uniquePrices.length > 0) {
    result["_all_prices"] = uniquePrices;
    result["precio"] = uniquePrices[0];
  }
  const titleSelectors = [
    "h1",
    "h2",
    "h3",
    "h4",
    '[class*="title"]',
    '[class*="titulo"]',
    '[class*="name"]',
    '[class*="product"]',
    "a"
  ];
  const allTitles = titleSelectors.flatMap((sel) => getAllText(sel));
  const validTitles = allTitles.filter((t) => t.length > 3 && !t.startsWith("http"));
  if (validTitles.length > 0) {
    result["_all_titles"] = validTitles;
    result["titulo"] = validTitles[0];
    result["title"] = validTitles[0];
  }
  const imageSelectors = ["img", "picture source", '[class*="image"]', '[class*="img"]'];
  const allImages = imageSelectors.flatMap((sel) => getAllImages(sel));
  const validImages = allImages.filter(
    (src) => src && !src.includes("data:image") && src.length > 20
  );
  if (validImages.length > 0) {
    result["_all_images"] = validImages;
    result["imagen"] = validImages[0];
    result["image"] = validImages[0];
  }
  const linkSelectors = ["a", "[href]"];
  const allLinks = linkSelectors.flatMap((sel) => getAllLinks(sel));
  const productLinks = allLinks.filter(
    (href) => href && !href.includes("javascript") && href.length > 20
  );
  if (productLinks.length > 0) {
    result["_all_urls"] = productLinks;
    result["url"] = productLinks[0];
    result["url_producto"] = productLinks[0];
  }
  const MAX_SHORT_FIELD_LEN = 60;
  const firstShortText = (selectors) => {
    for (const sel of selectors) {
      for (const { text } of getAllTextEls(sel)) {
        if (text.length > 0 && text.length <= MAX_SHORT_FIELD_LEN) return text;
      }
    }
    return null;
  };
  const ratingSelectors = [
    '[itemprop="ratingValue"]',
    '[class*="rating" i]',
    '[class*="stars" i]',
    '[aria-label*="star" i]'
  ];
  let ratingText = null;
  for (const sel of ratingSelectors) {
    for (const el of Array.from(container.querySelectorAll(sel))) {
      const text = el.textContent?.trim() ?? "";
      const aria = el.getAttribute("aria-label")?.trim() ?? "";
      const candidate = text.length > 0 ? text : aria;
      if (candidate.length > 0 && candidate.length <= MAX_SHORT_FIELD_LEN) {
        ratingText = candidate;
        break;
      }
    }
    if (ratingText) break;
  }
  if (ratingText) {
    const parsedRating = parseLocalizedPrice(ratingText);
    if (parsedRating !== null && parsedRating >= 0 && parsedRating <= 10) {
      result["rating"] = parsedRating;
    }
  }
  const marca = firstShortText(['[itemprop="brand"]', '[class*="brand" i]', '[class*="marca" i]']);
  if (marca) result["marca"] = marca;
  const skuAttr = container.querySelector("[data-sku]")?.getAttribute("data-sku")?.trim();
  const sku = skuAttr || firstShortText(['[itemprop="sku"]', '[class*="sku" i]']);
  if (sku) result["sku"] = sku;
  const disponibilidad = firstShortText([
    '[itemprop="availability"]',
    '[class*="stock" i]',
    '[class*="disponib" i]',
    '[class*="availability" i]'
  ]);
  if (disponibilidad) result["disponibilidad"] = disponibilidad;
  const descuento = firstShortText(['[class*="discount" i]', '[class*="descuento" i]']);
  if (descuento) result["descuento"] = descuento;
  const allText = container.textContent?.trim() ?? "";
  if (allText.length > 0) {
    result["_raw_text"] = allText;
  }
  return result;
}
const EXTRACT_ALL_PLACEHOLDER_SELECTOR = "[extractAll]";
function hasRealFieldMappings(mappings) {
  return mappings.some((m) => m.selector && m.selector !== EXTRACT_ALL_PLACEHOLDER_SELECTOR);
}
function extractProducts(rule) {
  const products = [];
  const useFieldMappings = hasRealFieldMappings(rule.fieldMappings);
  const containers = document.querySelectorAll(rule.containerSelector);
  containers.forEach((container) => {
    const items = Array.from(container.children).filter(
      (child) => child.children.length > 0
    );
    if (items.length > 0) {
      for (const item of items) {
        const p = useFieldMappings ? extractFieldsFromElement(item, rule.fieldMappings) : extractAllFromContainer(item);
        if (p && Object.keys(p).length > 0) products.push(p);
      }
    } else {
      const p = useFieldMappings ? extractFieldsFromElement(container, rule.fieldMappings) : extractAllFromContainer(container);
      if (p && Object.keys(p).length > 0) products.push(p);
    }
  });
  if (useFieldMappings) {
    const globals = extractProductsGlobal(rule.fieldMappings);
    if (globals.length > 0) return globals;
  }
  return products;
}
